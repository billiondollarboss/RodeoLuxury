A Pen created at CodePen.io. You can find this one at https://codepen.io/jcoulterdesign/pen/ZxXbeP.

 Explore the planets and moons of our solar system in pure CSS. Not a single line of JS used throughout, only images are planet textures taken from royalty free sites. Information about planets taken from space.com.

This works on  opera but is super jerky, Firefox has some issues with z-index. Mobile....no